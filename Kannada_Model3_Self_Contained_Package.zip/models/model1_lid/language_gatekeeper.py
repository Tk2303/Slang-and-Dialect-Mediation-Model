"""
Model 1: Hierarchical Kannada Language and Script Identification Gatekeeper.
Accurately distinguishes between:
- KANNADA_NATIVE: Pure Kannada script
- KANGLISH_ROMANIZED: Romanized / transliterated colloquial Kannada
- CODE_MIXED_KAN_ENG: Kannada mixed with English tokens
- ENGLISH: Standard English utterances
- OTHER_NON_KANNADA: Unrelated languages, noise, or gibberish
"""

import os
import re
import sys
from typing import Dict, Any, Tuple, List

# Core colloquial Kanglish lexicon (North Karnataka + Bengaluru + General Kannada)
KANGLISH_LEXICON = {
    # Pronouns & interrogatives
    "idhu", "adhu", "idu", "adu", "ivaga", "eega", "ega", "ellige", "elliye", "elli",
    "en", "enu", "yake", "yaak", "yaake", "yaakandre", "yaava", "yaavdhu", "yavdu",
    "naanu", "naavu", "neenu", "neevu", "avanu", "avalu", "avru", "avaru", "nange",
    "nanage", "nimge", "nimage", "namge", "namage", "avange", "avarge", "ivanu", "ivaru",
    "hege", "henge", "hegiddiya", "hegidhdhiya", "hegidira", "eshtu", "esht",
    # Verbs & aux
    "madu", "madi", "madthidiya", "madtini", "madoke", "madbedi", "madbeku", "madidhe",
    "madidhu", "aaythu", "aythu", "agide", "aagidhe", "agalla", "aagalla", "baralla",
    "barthini", "bartha", "bandhe", "bandhbutte", "bandhavne", "hogu", "hogo", "hogi",
    "hogtini", "hoda", "hogona", "hogoonu", "kuthkondevi", "irathara", "iruthadhe",
    "iralla", "idheevi", "iddini", "iddene", "kodu", "bidi", "bidu", "kelu", "keli",
    "kelthare", "nodri", "nodi", "nodu", "thorasbidu", "helu", "heli", "helidhe",
    "oppkondru", "thago", "thagondre", "tharthane", "kalisu", "kalisi",
    # Dialect markers (NK & BLR)
    "ayti", "aithi", "aythi", "aithei", "cholo", "chulo", "agadi", "agdi", "rokka",
    "bada", "beda", "bedri", "byadre", "byadree", "hontaara", "hontara", "khare",
    "mariyara", "mariya", "dosta", "dostha", "macha", "machaa", "magane", "maga",
    "guru", "kiriq", "kirik", "scene", "scenes", "chindi", "bombaat", "bombat",
    "loffar", "loafer", "bejjaan", "bejan", "sakkat", "sakkath", "huduga", "hudugi",
    "manege", "maneyalli", "maniyaga", "oorige", "oota", "chaha", "rotti", "palya",
    "sanji", "sanje", "naale", "ivathu", "ivattu", "munche", "thadi", "ashte", "illa",
    "halla", "alva", "alvaa", "kano", "kanro", "kanree", "nodappa", "houdu", "howdu",
    # Common formal / conversational terms
    "samanya", "vakya", "kannada", "vishaya", "namaskara", "shanta", "preethi", "sneha",
    "sneharu", "college", "shale", "kelasa", "sahaya", "dhanyavada", "shubhadina"
}

ENGLISH_STOPWORDS = {
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for",
    "not", "on", "with", "he", "as", "you", "do", "at", "this", "but", "his",
    "by", "from", "they", "we", "say", "her", "she", "or", "an", "will", "my",
    "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
    "about", "who", "get", "which", "go", "me", "when", "make", "can", "like",
    "time", "no", "just", "him", "know", "take", "people", "into", "year", "your",
    "good", "some", "could", "them", "see", "other", "than", "then", "now", "look",
    "only", "come", "its", "over", "think", "also", "back", "after", "use", "two",
    "how", "our", "work", "first", "well", "way", "even", "new", "want", "because",
    "any", "these", "give", "day", "most", "us", "morning", "everyone", "everyone's",
    "hello", "hi", "hey", "dear", "sir", "madam", "thanks", "thank", "welcome"
}


class KannadaLanguageGatekeeper:
    """
    Model 1 Gatekeeper for hierarchical language and script validation.
    """
    
    def __init__(self):
        self.kannada_regex = re.compile(r"[\u0C80-\u0CFF]")
        self.latin_regex = re.compile(r"[a-zA-Z]")
        self.other_indic_regex = re.compile(r"[\u0900-\u097F\u0B80-\u0BFF\u0C00-\u0C7F\u0D00-\u0D7F]")
        
    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Hierarchically classifies the input text into one of the 5 defined classes.
        """
        if not text or not text.strip():
            return {
                "label": "OTHER_NON_KANNADA",
                "confidence": 1.0,
                "script": "EMPTY",
                "is_valid_kannada": False,
                "reason": "Empty or whitespace-only input"
            }
            
        cleaned = text.strip()
        total_chars = len(cleaned)
        kn_chars = len(self.kannada_regex.findall(cleaned))
        latin_chars = len(self.latin_regex.findall(cleaned))
        other_indic_chars = len(self.other_indic_regex.findall(cleaned))
        
        kn_ratio = kn_chars / max(1, total_chars)
        latin_ratio = latin_chars / max(1, total_chars)
        other_ratio = other_indic_chars / max(1, total_chars)
        
        # Rule 1: Non-Kannada Indic scripts (Hindi, Tamil, Telugu, Malayalam)
        if other_ratio > 0.4 and kn_chars == 0:
            return {
                "label": "OTHER_NON_KANNADA",
                "confidence": round(other_ratio, 3),
                "script": "OTHER_INDIC",
                "is_valid_kannada": False,
                "reason": "Dominant non-Kannada Indic script detected"
            }
            
        # Rule 2: Native Kannada Script
        if kn_ratio > 0.35:
            # Check for English tokens within Kannada script (Code-mixed native script)
            words = re.findall(r"\b[a-zA-Z]+\b", cleaned)
            if len(words) >= 2 and latin_ratio > 0.2:
                return {
                    "label": "CODE_MIXED_KAN_ENG",
                    "confidence": 0.92,
                    "script": "KANNADA_AND_LATIN",
                    "is_valid_kannada": True,
                    "reason": "Mixed Kannada script with English Latin tokens"
                }
            return {
                "label": "KANNADA_NATIVE",
                "confidence": round(min(0.99, kn_ratio + 0.3), 3),
                "script": "KANNADA",
                "is_valid_kannada": True,
                "reason": "Dominant native Kannada script characters"
            }
            
        # Rule 3: Latin script analysis (Kanglish vs Code-mixed vs English vs Distractor)
        words = [w.lower() for w in re.findall(r"\b[a-zA-Z0-9'-]+\b", cleaned)]
        if not words:
            return {
                "label": "OTHER_NON_KANNADA",
                "confidence": 0.85,
                "script": "SYMBOLS_PUNCTUATION",
                "is_valid_kannada": False,
                "reason": "No recognizable word tokens"
            }
            
        kanglish_hits = 0
        english_hits = 0
        total_words = len(words)
        
        for w in words:
            if w in KANGLISH_LEXICON:
                kanglish_hits += 1
            elif any(w.endswith(suf) for suf in ["agide", "ide", "aagidhe", "thini", "thidiya", "beku", "beda", "alla", "aagalla"]):
                kanglish_hits += 1
            if w in ENGLISH_STOPWORDS:
                english_hits += 1
                
        # Sub-rule 3a: Clear Romanized Kannada / Kanglish
        if kanglish_hits > 0 and english_hits == 0:
            confidence = min(0.98, 0.75 + (kanglish_hits / total_words) * 0.25)
            return {
                "label": "KANGLISH_ROMANIZED",
                "confidence": round(confidence, 3),
                "script": "LATIN_KANGLISH",
                "is_valid_kannada": True,
                "reason": f"Strong Romanized Kannada vocabulary matches ({kanglish_hits}/{total_words} tokens)"
            }
            
        # Sub-rule 3b: Code-mixed Kannada and English
        if kanglish_hits > 0 and english_hits > 0:
            return {
                "label": "CODE_MIXED_KAN_ENG",
                "confidence": 0.94,
                "script": "LATIN_CODE_MIXED",
                "is_valid_kannada": True,
                "reason": f"Both Kannada terms ({kanglish_hits}) and English terms ({english_hits}) detected"
            }
            
        # Sub-rule 3c: Pure English
        if english_hits >= 2 or (english_hits >= 1 and total_words <= 3 and kanglish_hits == 0):
            confidence = min(0.98, 0.70 + (english_hits / total_words) * 0.3)
            return {
                "label": "ENGLISH",
                "confidence": round(confidence, 3),
                "script": "LATIN_ENGLISH",
                "is_valid_kannada": False,
                "reason": f"English vocabulary detected ({english_hits}/{total_words} tokens) without Kannada markers"
            }
            
        # Sub-rule 3d: Check for common English greetings / phrases
        english_phrases = ["good morning", "good evening", "how are you", "thank you", "hello everyone", "what is this"]
        lower_cleaned = cleaned.lower()
        if any(p in lower_cleaned for p in english_phrases):
            return {
                "label": "ENGLISH",
                "confidence": 0.96,
                "script": "LATIN_ENGLISH",
                "is_valid_kannada": False,
                "reason": "Standard English phrase match"
            }
            
        # Sub-rule 3e: Single-word or ambiguous Kanglish with phonological heuristics
        # Kannada words commonly end in vowels: -a, -e, -i, -o, -u
        vowel_end_words = sum(1 for w in words if w.endswith(('a', 'e', 'i', 'o', 'u')))
        if vowel_end_words / total_words >= 0.75 and total_words >= 2:
            return {
                "label": "KANGLISH_ROMANIZED",
                "confidence": 0.78,
                "script": "LATIN_KANGLISH",
                "is_valid_kannada": True,
                "reason": "Phonotactic structure matches Dravidian / Kannada transliteration"
            }
            
        # Default fallback
        return {
            "label": "OTHER_NON_KANNADA",
            "confidence": 0.70,
            "script": "UNKNOWN_LATIN",
            "is_valid_kannada": False,
            "reason": "Latin script without verified Kannada or English vocabulary"
        }

if __name__ == "__main__":
    gate = KannadaLanguageGatekeeper()
    test_cases = [
        "idhu samanya kannada vakya",
        "ayti nodri",
        "tumba cholo agide",
        "en madthidiya",
        "hegiddiya macha",
        "Good morning everyone",
        "I am coming manege",
        "ಹೌದ್ಲೇ ಮರಿಯಾ, ನಾಳೆ ನಾವೆಲ್ಲ ಬಾಗಲಕೋಟಿಗೆ ಹೋಗೂನು.",
        "Today weather is very sunny in Bengaluru.",
        "Comment ça va mon ami?",
        "ಯಾಕ ಹಂಗ ಮಾಡ್ತಿ? ಸ್ವಲ್ಪ ಶಾಂತವಾಗಿ ಇರು."
    ]
    print("=" * 70)
    print("TESTING UPGRADED MODEL 1: KANNADA LANGUAGE & SCRIPT GATEKEEPER")
    print("=" * 70)
    for tc in test_cases:
        res = gate.analyze(tc)
        print(f"Input:       '{tc}'")
        print(f"Decision:    {res['label']} (Confidence: {res['confidence']:.2f}, Script: {res['script']})")
        print(f"Is Valid KN: {res['is_valid_kannada']} | Reason: {res['reason']}\n")

